# python-path

Your exercise repo for the Python → Data Engineering path.
The lessons, quizzes and progress tracker live on the **Python Path** web page; this repo is where you write code.

Every exercise is a function stub that raises `NotImplementedError`. You replace the body, run the
tests, and you're done when they're green. **Never edit the tests to make them pass.**

```
exercises/w00_setup.py ... w06_cli.py   <- you write code here
exercises/w04p_pandas.py                <- pandas & NumPy (pip install pandas first)
tests/test_w00_setup.py ...             <- you run these, don't touch them
practice_data/                          <- lab files (census, sales, jobs) + loans.json
CHEATSHEET.md                           <- grep it while you work
```

---

## Week 0: setup (do this once, in order)

Open the **Terminal** app (or VS Code's terminal: `` ctrl+` ``).

### 1. Look around
```bash
pwd                      # where am I?
cd ~/code/python-path    # go to the repo
ls -la                   # what's here (including hidden files like .gitignore)
```

### 2. VS Code
1. Install VS Code from https://code.visualstudio.com if you haven't.
2. In VS Code: `cmd+shift+P` → **Shell Command: Install 'code' command in PATH**.
3. Install the extensions **Python** and **Python Debugger** (both from Microsoft).
4. From the terminal: `code .` opens this folder.

### 3. Virtual environment
A venv is a private copy of Python for one project, so package versions never clash between projects.
```bash
python3 -m venv .venv          # create it (once per project)
source .venv/bin/activate      # activate it (every new terminal); prompt shows (.venv)
python -m pip install pytest   # install into THIS project only
python -m pip freeze > requirements.txt   # record what you installed
```
In VS Code: `cmd+shift+P` → **Python: Select Interpreter** → pick `.venv`.
Check: `which python` must print a path ending in `python-path/.venv/bin/python`.

> You have miniconda. If your prompt shows `(base)`, that's conda's environment, not your venv.
> Activate `.venv` anyway, because the venv wins. Optional: `conda config --set auto_activate_base false`.

### 4. First green test
```bash
pytest tests/test_w00_setup.py        # red: stubs not written yet
# open exercises/w00_setup.py, write the functions
pytest tests/test_w00_setup.py        # green
```

### 5. Git + GitHub
```bash
git init                               # start tracking this folder
git status                             # what changed?
git add .                              # stage everything (.gitignore keeps .venv out)
git commit -m "Initial commit: exercise repo"
gh auth login                          # GitHub.com → HTTPS → login with browser
gh repo create python-path --private --source=. --push
```
From now on, at the end of every session:
```bash
git add -A && git commit -m "w02: group_by and aggregate" && git push
```

---

## Daily loop (15 h/week ≈ 2.5 h/day, 6 days)

1. **30 min**: lesson on the web page plus the book chapters it lists.
2. **90 min**: exercises. One function at a time: `pytest tests/test_w02_collections.py -k group_by`
3. **30 min**: quiz on the page, then commit and push.
4. **Sunday**: `/learn` review session with Claude. Explain 3 concepts back and get your pushed code reviewed.

Useful pytest flags:
```bash
pytest -k word_freq        # only tests whose name contains "word_freq"
pytest -x                  # stop at first failure
pytest -v                  # show every test name
pytest --lf                # rerun only the last failures
```

---

## Your DSS project repo (create it in Week 3)

This is **your** code, so nothing gets generated for you. A layout that keeps the graders happy and scales:

```
~/code/lds-project/                # outside Google Drive
  README.md          # how to run each assignment, in order
  requirements.txt   # pyodbc, ... (pip freeze)
  .gitignore         # data/, out/, .env, .venv/
  .env               # DB_SERVER=... DB_USER=... DB_PASSWORD=...  (NEVER committed)
  data/              # raw files (truth.csv, users.xml, ...). Point to Drive or copy here
  out/               # generated CSVs / JSON
  src/
    common.py        # shared helpers: readers, DB connection
    a1_explore.py
    a4_split_tables.py
    a5_upload.py
    a6_gather.py
  tests/             # small tests on tiny hand-made inputs
```
Each script runs as `python src/a4_split_tables.py --input data --out out` (you learn `argparse` in W6).
