import csv
from datetime import datetime
from pathlib import Path

import pytest

from exercises.w03_files import load_json, parse_arff
from exercises.w04_cleaning import (
    build_dimension,
    build_sales_star,
    categorize,
    clean_text,
    date_dimension_row,
    drop_duplicates,
    extract_hashtags,
    extract_urls,
    find_duplicates,
    hours_between,
    mean_std,
    parse_timestamp,
    row_key,
    season,
    write_tables,
    zscore_outliers,
)

DATA = Path(__file__).parent.parent / "practice_data"


def test_parse_timestamp_both_formats():
    expected = datetime(1994, 9, 14, 8, 30)
    assert parse_timestamp("1994-09-14 08:30:00") == expected
    assert parse_timestamp("1994-09-14T08:30:00") == expected
    with pytest.raises(ValueError):
        parse_timestamp("14/09/1994")


@pytest.mark.parametrize("month,name", [(12, "winter"), (1, "winter"), (2, "winter"), (3, "spring"),
                                        (6, "summer"), (8, "summer"), (9, "autumn"), (11, "autumn")])
def test_season(month, name):
    assert season(datetime(2024, month, 1)) == name


def test_date_dimension_row():
    assert date_dimension_row(datetime(1994, 9, 14, 23, 59)) == {
        "date_id": 19940914, "date": "1994-09-14", "day": 14, "month": 9, "year": 1994,
        "quarter": 3, "weekday": "Wednesday", "season": "autumn",
    }


def test_hours_between():
    assert hours_between("2024-01-01 22:00:00", "2024-01-02T01:30:00") == 3.5
    assert hours_between("2024-01-02 00:00:00", "2024-01-01 00:00:00") == -24


def test_row_key():
    assert row_key({"b": 2, "a": 1}, None) == (("a", 1), ("b", 2))
    assert row_key({"b": 2, "a": 1}, ["b"]) == (2,)
    assert row_key({"x": 1, "y": 2}, ["y", "x"]) == (2, 1)
    assert row_key({"a": 1, "b": 2}, None) == row_key({"b": 2, "a": 1}, None)  # key order doesn't matter


def test_duplicates_on_loans():
    events = load_json(DATA / "loans.json")["events"]
    assert len(events) == 82
    assert find_duplicates(events, ["event_id"]) == [(11,), (21,)]
    assert len(find_duplicates(events, None)) == 2
    clean = drop_duplicates(events)
    assert len(clean) == 80
    assert [e["event_id"] for e in clean] == list(range(1, 81))


def test_drop_duplicates_by_key_keeps_first():
    rows = [{"id": 1, "v": "a"}, {"id": 1, "v": "b"}, {"id": 2, "v": "c"}]
    assert drop_duplicates(rows, ["id"]) == [{"id": 1, "v": "a"}, {"id": 2, "v": "c"}]


def test_mean_std_edge_cases():
    assert mean_std([]) == (None, None)
    assert mean_std([None, None]) == (None, None)
    assert mean_std([5]) == (5.0, 0.0)
    m, s = mean_std([2, 4, 4, 4, 5, 5, 7, 9, None])
    assert m == 5 and s == pytest.approx(2.138, abs=1e-3)


def test_zscore_outliers():
    qty = [5, 3, 50, 75, 10, 40, 20, 20, 20, 3, 25, 15, 25, 35, 15, 10, 10, 25, 15, 30, 25]
    assert zscore_outliers(qty, k=2) == [3]
    assert zscore_outliers([7, 7, 7]) == []
    assert zscore_outliers([1, None, 1, 1, 1, 1, 1, 1, 1, 1, 100], k=2) == [10]


def test_clean_text():
    assert clean_text("  hello \n\t  world  ") == "hello world"
    assert clean_text(None) == ""


def test_extract_hashtags_and_urls():
    assert extract_hashtags("Go #Python and #DataEng! #python") == ["python", "dataeng", "python"]
    assert extract_hashtags("no tags") == []
    text = "Docs: https://docs.python.org/3/library/csv.html. Also (see http://example.com)!"
    assert extract_urls(text) == ["https://docs.python.org/3/library/csv.html", "http://example.com"]


def test_categorize():
    rules = {
        "data": ["sql", "pipeline", "warehouse"],
        "art": ["art", "painting"],
        "sport": ["football", "tennis"],
    }
    assert categorize("Building a PIPELINE in Python", rules) == "data"
    assert categorize("Let's start the tennis match", rules) == "sport"  # "start" is not "art"
    assert categorize("Modern art and SQL", rules) == "data"  # first category in rule order wins
    assert categorize("nothing here", rules) == "other"
    assert categorize("nothing here", rules, default="misc") == "misc"


def test_build_dimension():
    rows = [{"c": "IT", "city": "Pisa"}, {"c": "FR", "city": "Paris"}, {"c": "IT", "city": "Pisa"}]
    dim, lookup = build_dimension(rows, ["c", "city"], "place_key")
    assert dim == [{"place_key": 1, "c": "IT", "city": "Pisa"}, {"place_key": 2, "c": "FR", "city": "Paris"}]
    assert lookup == {("IT", "Pisa"): 1, ("FR", "Paris"): 2}


def test_build_sales_star():
    star = build_sales_star(parse_arff(DATA / "sales.arff")["rows"])
    assert set(star) == {"dim_store", "dim_title", "dim_date", "fact_sales"}
    assert len(star["dim_store"]) == 6 and len(star["dim_title"]) == 16 and len(star["dim_date"]) == 10
    assert star["dim_date"][0]["date_id"] == 19920615 and star["dim_date"][0]["weekday"] == "Monday"
    facts = star["fact_sales"]
    assert len(facts) == 21
    assert facts[2] == {"ord_num": "A2976", "store_key": 2, "title_key": 3, "date_id": 19930524,
                        "payterms": "Net 30", "qty": 50}
    assert sum(f["qty"] for f in facts) == 493
    # referential integrity: every foreign key exists in its dimension
    assert {f["store_key"] for f in facts} <= {d["store_key"] for d in star["dim_store"]}
    assert {f["date_id"] for f in facts} <= {d["date_id"] for d in star["dim_date"]}


def test_write_tables(tmp_path):
    star = build_sales_star(parse_arff(DATA / "sales.arff")["rows"])
    counts = write_tables(star, tmp_path / "star")
    assert counts == {"dim_store": 6, "dim_title": 16, "dim_date": 10, "fact_sales": 21}
    with open(tmp_path / "star" / "fact_sales.csv", encoding="utf-8", newline="") as f:
        header = next(csv.reader(f))
    assert header == ["ord_num", "store_key", "title_key", "date_id", "payterms", "qty"]
