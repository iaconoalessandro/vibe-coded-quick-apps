import json
import sqlite3
from pathlib import Path

import pytest

from exercises.w03_files import parse_arff
from exercises.w04_cleaning import build_sales_star, write_tables
from exercises.w05_db import (
    batched,
    create_star_schema,
    db_settings,
    export_query_to_json,
    insert_rows,
    iter_csv_rows,
    load_star_from_csv,
    qty_by_store,
    qty_by_year_season,
    sqlserver_connection_string,
)

DATA = Path(__file__).parent.parent / "practice_data"


@pytest.fixture
def conn():
    c = sqlite3.connect(":memory:")  # a throwaway database in RAM
    yield c
    c.close()


@pytest.fixture
def star_csv(tmp_path):
    write_tables(build_sales_star(parse_arff(DATA / "sales.arff")["rows"]), tmp_path)
    return tmp_path


def test_batched():
    assert list(batched(range(5), 2)) == [[0, 1], [2, 3], [4]]
    assert list(batched([], 3)) == []
    gen = batched((x for x in range(10**12)), 3)  # infinite-ish input: must stay lazy
    assert next(gen) == [0, 1, 2]
    with pytest.raises(ValueError):
        list(batched([1], 0))


def test_iter_csv_rows_is_lazy(star_csv):
    rows = iter_csv_rows(star_csv / "dim_store.csv")
    assert not isinstance(rows, list)
    assert next(rows) == {"store_key": "1", "stor_id": "6380"}


def test_create_star_schema(conn):
    create_star_schema(conn)
    create_star_schema(conn)  # running twice must not fail
    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert tables == {"dim_store", "dim_title", "dim_date", "fact_sales"}
    cols = [r[1] for r in conn.execute("PRAGMA table_info(fact_sales)")]
    assert cols == ["ord_num", "store_key", "title_key", "date_id", "payterms", "qty"]


def test_insert_rows_batches_and_params(conn):
    conn.execute("CREATE TABLE t (id INTEGER, name TEXT)")
    rows = ({"id": i, "name": f"O'Brien {i}"} for i in range(1234))  # apostrophes: placeholders handle them
    assert insert_rows(conn, "t", rows, batch_size=100) == 1234
    assert conn.execute("SELECT COUNT(*), MAX(id) FROM t").fetchone() == (1234, 1233)
    assert insert_rows(conn, "t", []) == 0


def test_insert_rows_rejects_unsafe_names(conn):
    conn.execute("CREATE TABLE t (id INTEGER)")
    with pytest.raises(ValueError):
        insert_rows(conn, "t; DROP TABLE t", [{"id": 1}])
    with pytest.raises(ValueError):
        insert_rows(conn, "t", [{"id) VALUES (1); --": 1}])


def test_load_and_query(conn, star_csv):
    counts = load_star_from_csv(conn, star_csv)
    assert counts == {"dim_store": 6, "dim_title": 16, "dim_date": 10, "fact_sales": 21}
    by_store = qty_by_store(conn)
    assert len(by_store) == 6
    assert sum(t for _, t in by_store) == 493
    assert by_store[0] == ("7131", 130)
    assert [t for _, t in by_store] == sorted((t for _, t in by_store), reverse=True)
    assert qty_by_year_season(conn)[0] == (1992, "summer", 80)


def test_export_query_to_json(conn, star_csv, tmp_path):
    load_star_from_csv(conn, star_csv)
    out = tmp_path / "exports" / "big.json"
    n = export_query_to_json(conn, "SELECT ord_num, qty FROM fact_sales WHERE qty >= ?", out, (20,), chunk_size=4)
    data = json.loads(out.read_text(encoding="utf-8"))
    assert n == len(data) == 13
    assert set(data[0]) == {"ord_num", "qty"}
    assert export_query_to_json(conn, "SELECT * FROM fact_sales WHERE qty < 0", out) == 0
    assert json.loads(out.read_text(encoding="utf-8")) == []


def test_db_settings():
    env = {"DB_SERVER": "srv", "DB_NAME": "Group_00_DB", "DB_USER": "me", "DB_PASSWORD": "pw", "HOME": "/x"}
    assert db_settings(env) == {"server": "srv", "database": "Group_00_DB", "user": "me", "password": "pw"}
    with pytest.raises(KeyError) as err:
        db_settings({"DB_SERVER": "srv"})
    assert "DB_NAME" in str(err.value) and "DB_PASSWORD" in str(err.value)


def test_sqlserver_connection_string():
    s = {"server": "srv", "database": "db", "user": "u", "password": "p"}
    assert sqlserver_connection_string(s) == (
        "DRIVER={ODBC Driver 18 for SQL Server};SERVER=srv;DATABASE=db;UID=u;PWD=p;TrustServerCertificate=yes"
    )
