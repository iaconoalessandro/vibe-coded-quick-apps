import pytest

from exercises.w02_collections import (
    aggregate,
    append_copy,
    binary_search,
    column,
    common_and_only,
    depth,
    flatten,
    group_by,
    index_by,
    invert_dict,
    join,
    merge_counts,
    merge_sort,
    min_max,
    sales_summary,
    second_largest,
    squares_of_odds,
    top_n,
    transpose,
    unique_in_order,
    word_frequencies,
)

ROWS = [
    {"store": "S1", "title": "T1", "qty": 5},
    {"store": "S2", "title": "T2", "qty": 3},
    {"store": "S1", "title": "T2", "qty": 2},
    {"store": "S1", "title": "T2", "qty": 4},
    {"store": "S2", "title": "T1", "qty": 3},
]


def test_second_largest():
    assert second_largest([3, 9, 9, 1]) == 3
    assert second_largest([5, 5]) is None
    assert second_largest([]) is None


def test_unique_in_order():
    assert unique_in_order(["b", "a", "b", "c", "a"]) == ["b", "a", "c"]
    assert unique_in_order([]) == []


def test_append_copy_does_not_mutate():
    lst = [1, 2]
    new = append_copy(lst, 3)
    assert new == [1, 2, 3]
    assert lst == [1, 2], "the original list changed: you mutated it instead of copying"


def test_min_max():
    assert min_max([3, -1, 7, 2]) == (-1, 7)
    assert min_max([4]) == (4, 4)
    with pytest.raises(ValueError):
        min_max([])


def test_transpose():
    assert transpose([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]
    assert transpose([]) == []


def test_squares_of_odds():
    assert squares_of_odds([1, 2, 3, 4, 5]) == [1, 9, 25]


def test_word_frequencies():
    assert word_frequencies("The cat. The DOG!") == {"the": 2, "cat": 1, "dog": 1}
    assert word_frequencies("") == {}


def test_top_n_ties_alphabetical():
    freqs = {"b": 2, "a": 2, "c": 5, "d": 1}
    assert top_n(freqs, 3) == [("c", 5), ("a", 2), ("b", 2)]


def test_invert_dict():
    assert invert_dict({"a": 1, "b": 2, "c": 1}) == {1: ["a", "c"], 2: ["b"]}


def test_merge_counts_pure():
    a, b = {"x": 1, "y": 2}, {"y": 3, "z": 1}
    assert merge_counts(a, b) == {"x": 1, "y": 5, "z": 1}
    assert a == {"x": 1, "y": 2} and b == {"y": 3, "z": 1}


def test_common_and_only():
    assert common_and_only([3, 1, 2, 2], [2, 3, 4]) == ([2, 3], [1], [4])


def test_column():
    assert column([{"a": 1}, {"b": 2}], "a") == [1, None]


def test_group_by():
    g = group_by(ROWS, "store")
    assert set(g) == {"S1", "S2"}
    assert [r["qty"] for r in g["S1"]] == [5, 2, 4]


@pytest.mark.parametrize(
    "how,expected",
    [("sum", {"S1": 11, "S2": 6}), ("count", {"S1": 3, "S2": 2}), ("max", {"S1": 5, "S2": 3})],
)
def test_aggregate(how, expected):
    assert aggregate(ROWS, "store", "qty", how) == expected


def test_aggregate_mean_and_errors():
    assert aggregate(ROWS, "store", "qty", "mean") == {"S1": pytest.approx(11 / 3), "S2": 3.0}
    with pytest.raises(ValueError):
        aggregate(ROWS, "store", "qty", "median")


def test_index_by_and_join():
    people = [{"id": 1, "name": "Ada"}, {"id": 2, "name": "Alan"}]
    cities = [{"id": 2, "city": "London"}, {"id": 1, "city": "Pisa"}, {"id": 9, "city": "Nowhere"}]
    assert index_by(people, "id")[2]["name"] == "Alan"
    with pytest.raises(ValueError):
        index_by(people + [{"id": 1, "name": "dup"}], "id")
    assert join(people, cities, "id") == [
        {"id": 1, "name": "Ada", "city": "Pisa"},
        {"id": 2, "name": "Alan", "city": "London"},
    ]
    assert people[0] == {"id": 1, "name": "Ada"}, "join must not modify its inputs"


def test_sales_summary():
    assert sales_summary(ROWS) == {
        "S1": {"orders": 3, "qty": 11, "top_title": "T2"},
        "S2": {"orders": 2, "qty": 6, "top_title": "T1"},  # tie 3-3 -> alphabetical
    }


def test_flatten_and_depth():
    assert flatten([1, [2, [3, [4]], 5]]) == [1, 2, 3, 4, 5]
    assert flatten([]) == []
    assert depth([]) == 1
    assert depth([1, [2, [3]]]) == 3


def test_binary_search():
    data = [1, 3, 5, 7, 9, 11]
    for i, x in enumerate(data):
        assert binary_search(data, x) == i
    assert binary_search(data, 4) == -1
    assert binary_search([], 1) == -1


def test_merge_sort():
    nums = [5, -2, 9, 0, 5, 1]
    assert merge_sort(nums) == [-2, 0, 1, 5, 5, 9]
    assert nums == [5, -2, 9, 0, 5, 1]
    assert merge_sort([]) == []
