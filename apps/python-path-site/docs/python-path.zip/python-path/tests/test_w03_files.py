from pathlib import Path

from exercises.w03_files import (
    borrows_per_member,
    convert_types,
    count_lines,
    count_values_streaming,
    load_json,
    missing_report,
    parse_arff,
    read_csv_rows,
    read_header_file,
    read_text_safely,
    save_json,
    to_number,
    write_csv,
    xml_attribute_rows,
    xml_element_rows,
)

DATA = Path(__file__).parent.parent / "practice_data"


def test_count_lines():
    # jobs.csv has no newline after its last line: `wc -l` says 13, Python sees 14 lines
    assert count_lines(DATA / "jobs.csv") == 14


def test_read_header_file():
    names = read_header_file(DATA / "census.header")
    assert len(names) == 15
    assert names[:3] == ["age", "workclass", "fnlwgt"]
    assert names[-1] == "income"


def test_read_csv_rows_with_external_header():
    rows = read_csv_rows(DATA / "census_selected.csv", read_header_file(DATA / "census.header"))
    assert len(rows) == 100
    assert rows[0]["age"] == "39" and rows[0]["workclass"] == "State-gov"


def test_write_then_read_roundtrip(tmp_path):
    rows = [{"id": "1", "name": "Ada, Countess"}, {"id": "2", "name": 'say "hi"'}]
    out = tmp_path / "nested" / "people.csv"
    assert write_csv(rows, out, ["id", "name"]) == 2
    assert read_csv_rows(out) == rows  # commas and quotes inside values survive


def test_to_number():
    assert to_number("42") == 42 and isinstance(to_number("42"), int)
    assert to_number(" 3.5 ") == 3.5
    assert to_number("?") is None and to_number("") is None and to_number("   ") is None
    assert to_number(" Private ") == "Private"


def test_convert_types_and_missing_report():
    rows = read_csv_rows(DATA / "census_selected.csv", read_header_file(DATA / "census.header"))
    typed = convert_types(rows)
    assert typed[0]["age"] == 39 and typed[0]["fnlwgt"] == 77516
    assert missing_report(rows) == {"native-country": 5, "workclass": 4, "occupation": 4}
    assert missing_report(typed) == {"native-country": 5, "workclass": 4, "occupation": 4}
    assert rows[0]["age"] == "39", "convert_types must return new rows"


def test_parse_arff_sales():
    arff = parse_arff(DATA / "sales.arff")
    assert arff["relation"] == "QueryResult"
    assert [name for name, _ in arff["attributes"]] == ["stor_id", "ord_num", "ord_date", "qty", "payterms", "title_id"]
    assert arff["attributes"][4][1].startswith("{")
    assert len(arff["rows"]) == 21
    assert arff["rows"][3] == {
        "stor_id": "7066", "ord_num": "QA7442.3", "ord_date": "1994-09-13T00:00:00",
        "qty": "75", "payterms": "ON invoice", "title_id": "PS2091",
    }


def test_parse_arff_census_matches_csv():
    arff = parse_arff(DATA / "census_selected.arff")
    assert arff["relation"] == "census"
    assert len(arff["attributes"]) == 15 and len(arff["rows"]) == 100
    assert missing_report(arff["rows"]) == {"native-country": 5, "workclass": 4, "occupation": 4}


def test_parse_arff_edge_cases(tmp_path):
    f = tmp_path / "tiny.arff"
    f.write_text(
        "% a comment\n@RELATION 'tiny'\n\n@ATTRIBUTE name string\n@attribute note string\n"
        "@DATA\n% comment inside data\n'Rossi, Mario','ok'\nBianchi,?\n",
        encoding="utf-8",
    )
    arff = parse_arff(f)
    assert arff["relation"] == "tiny"
    assert arff["rows"] == [{"name": "Rossi, Mario", "note": "ok"}, {"name": "Bianchi", "note": "?"}]


def test_xml_attribute_rows():
    rows = xml_attribute_rows(DATA / "census_row.xml")
    assert len(rows) == 100
    assert rows[0]["age"] == "39" and rows[0]["class"] == "<=50K"  # &lt; decoded for you


def test_xml_element_rows_same_data():
    a = xml_attribute_rows(DATA / "census_row.xml")
    e = xml_element_rows(DATA / "census_elements.xml", "census")
    assert e == a


def test_count_values_streaming():
    assert count_values_streaming(DATA / "census_elements.xml", "census", "sex") == {"Male": 74, "Female": 26}


def test_json_roundtrip(tmp_path):
    obj = {"città": "Pisa", "n": [1, 2.5, None, True]}
    p = tmp_path / "sub" / "x.json"
    save_json(obj, p)
    assert load_json(p) == obj
    assert "città" in p.read_text(encoding="utf-8")


def test_borrows_per_member():
    assert borrows_per_member(DATA / "loans.json") == {
        "Ada": 4, "Alan": 4, "Barbara": 4, "Donald": 9, "Grace": 4,
        "Guido": 5, "Ken": 4, "Linus": 5, "Margaret": 6,
    }


def test_read_text_safely(tmp_path):
    assert read_text_safely(tmp_path / "nope.txt") is None
    bad = tmp_path / "latin1.txt"
    bad.write_bytes(b"caf\xe9")  # latin-1 "é" is invalid UTF-8
    assert read_text_safely(bad) == "caf�"
    good = tmp_path / "ok.txt"
    good.write_text("ciao", encoding="utf-8")
    assert read_text_safely(good) == "ciao"
