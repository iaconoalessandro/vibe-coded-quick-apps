from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from exercises.w04p_pandas import (
    add_date_parts,
    add_share_of_city,
    add_size_band,
    age_groups,
    clean_orders,
    clip_negative,
    column_stats,
    count_in_range,
    filter_orders,
    grade_bands,
    grid,
    join_customers,
    latest_per_customer,
    load_jobs,
    min_max_scale,
    monthly_pivot,
    one_hot,
    profile,
    sales_by_city,
    stack_months,
    tidy_posts,
    top_customers,
    wide_to_long,
)

DATA = Path(__file__).parent.parent / "practice_data"


@pytest.fixture
def orders():
    return pd.DataFrame({
        "order_id": [1, 2, 3, 4, 5],
        "customer": ["ada", "alan", "ada", "grace", "alan"],
        "city": ["Pisa", "Livorno", "Pisa", "Lucca", "Livorno"],
        "amount": [120.0, 35.5, 80.0, 210.0, 64.5],
        "date": pd.to_datetime(["2024-01-05", "2024-01-07", "2024-02-11", "2024-02-12", "2024-02-20"]),
    })


# ---------- NumPy ----------

def test_grid():
    assert grid(6, 3).tolist() == [[0, 1, 2], [3, 4, 5]]
    assert grid(6, 2).shape == (3, 2)


def test_column_stats():
    means, stds = column_stats(np.array([[1.0, 10.0], [3.0, 10.0]]))
    assert means.tolist() == [2.0, 10.0]
    assert stds.tolist() == [1.0, 0.0]


def test_min_max_scale():
    assert min_max_scale(np.array([10, 20, 30])).tolist() == [0.0, 0.5, 1.0]


def test_clip_negative():
    assert clip_negative(np.array([3, -1, 4, -5])).tolist() == [3, 0, 4, 0]


def test_count_in_range():
    result = count_in_range(np.array([1, 5, 10, 15, 20]), 5, 15)
    assert result == 3 and type(result) is int


def test_grade_bands():
    assert grade_bands(np.array([45, 50, 70, 84, 85, 99])).tolist() == ["F", "C", "B", "B", "A", "A"]


# ---------- inspect, select, filter ----------

def test_load_jobs():
    jobs = load_jobs(DATA / "jobs.csv")
    assert list(jobs.columns) == ["job_id", "title", "min_lvl", "max_lvl"]
    assert jobs.shape == (14, 4)
    assert jobs.loc[1, "title"] == "Chief Executive Officer"


def test_profile():
    df = pd.DataFrame({"a": [1, None, 3], "b": ["x", "y", None]})
    assert profile(df) == {"rows": 3, "cols": 2, "missing": {"a": 1, "b": 1}}


def test_filter_orders(orders):
    assert filter_orders(orders, ["Pisa", "Lucca"], 80, 200)["order_id"].tolist() == [1, 3]
    assert filter_orders(orders, ["Livorno"], 0, 35.5)["order_id"].tolist() == [2]


def test_top_customers(orders):
    assert top_customers(orders, 2) == ["grace", "ada"]


# ---------- cleaning ----------

def test_clean_orders():
    raw = pd.DataFrame({
        " Order_ID ": [1, 2, "?", 3, 3],
        "Customer": ["ada", "unknown", "alan", "grace", "grace"],
        "QTY": [2, -999, 1, "N/A", "N/A"],
        "Date": ["2024-01-05", "2024-01-07", "2024-01-08", "2024-02-12", "2024-02-12"],
    })
    df = clean_orders(raw)
    assert list(df.columns) == ["order_id", "customer", "qty", "date"]
    assert df["order_id"].tolist() == [1, 2, 3]
    assert df["qty"].tolist() == [2, 0, 0]
    assert df["customer"].isnull().tolist() == [False, True, False]
    assert pd.api.types.is_integer_dtype(df["order_id"]) and pd.api.types.is_integer_dtype(df["qty"])
    assert pd.api.types.is_datetime64_any_dtype(df["date"])


def test_latest_per_customer(orders):
    latest = latest_per_customer(orders)
    assert latest["customer"].tolist() == ["ada", "alan", "grace"]
    assert latest["order_id"].tolist() == [3, 5, 4]


def test_add_date_parts(orders):
    df = add_date_parts(orders)
    assert df["year"].tolist() == [2024] * 5
    assert df["month"].tolist() == [1, 1, 2, 2, 2]
    assert df["weekday"].tolist()[0] == "Friday"
    assert "year" not in orders.columns  # the original is untouched


def test_tidy_posts():
    posts = pd.DataFrame({"text": ["  Big SALE #deal #now ", "hello #world", "nothing here"]})
    df = tidy_posts(posts)
    assert df["text"].tolist() == ["big sale #deal #now", "hello #world", "nothing here"]
    assert df["n_hashtags"].tolist() == [2, 1, 0]
    assert df["mentions_sale"].tolist() == [True, False, False]
    assert "n_hashtags" not in posts.columns


# ---------- new columns ----------

def test_add_size_band(orders):
    assert add_size_band(orders)["size"].tolist() == ["medium", "low", "low", "high", "low"]


def test_age_groups():
    groups = age_groups(pd.Series([5, 18, 19, 65, 80]))
    assert groups.astype(str).tolist() == ["minor", "minor", "adult", "adult", "senior"]


def test_one_hot(orders):
    df = one_hot(orders, "city")
    assert "city" not in df.columns
    assert df["city_Pisa"].tolist() == [1, 0, 1, 0, 0]
    assert df["city_Livorno"].tolist() == [0, 1, 0, 0, 1]


# ---------- group, join, reshape ----------

def test_sales_by_city(orders):
    summary = sales_by_city(orders)
    assert list(summary.columns) == ["city", "total", "orders", "avg"]
    assert summary["city"].tolist() == ["Lucca", "Pisa", "Livorno"]
    assert summary["total"].tolist() == [210.0, 200.0, 100.0]
    assert summary["orders"].tolist() == [1, 2, 2]
    assert summary["avg"].tolist() == [210.0, 100.0, 50.0]
    assert summary.index.tolist() == [0, 1, 2]


def test_add_share_of_city(orders):
    assert add_share_of_city(orders)["share"].tolist() == pytest.approx([0.6, 0.355, 0.4, 1.0, 0.645])


def test_join_customers(orders):
    customers = pd.DataFrame({"customer": ["ada", "alan"], "country": ["UK", "UK"]})
    joined = join_customers(orders, customers)
    assert len(joined) == len(orders)
    assert joined["country"].isnull().tolist() == [False, False, False, True, False]
    duplicated = pd.concat([customers, customers])
    with pytest.raises(pd.errors.MergeError):
        join_customers(orders, duplicated)


def test_stack_months(orders):
    stacked = stack_months([orders.iloc[:2], orders.iloc[2:]])
    assert stacked.index.tolist() == [0, 1, 2, 3, 4]
    assert stacked["order_id"].tolist() == [1, 2, 3, 4, 5]


def test_monthly_pivot(orders):
    df = orders.assign(month=orders["date"].dt.month)
    pivot = monthly_pivot(df)
    assert pivot.loc["Pisa", 1] == 120.0 and pivot.loc["Pisa", 2] == 80.0
    assert pivot.loc["Lucca", 1] == 0
    assert pivot.loc["Livorno", 2] == 64.5


def test_wide_to_long():
    wide = pd.DataFrame({"city": ["Pisa", "Lucca"], "jan": [120, 0], "feb": [80, 210]})
    long = wide_to_long(wide)
    assert list(long.columns) == ["city", "month", "amount"]
    assert len(long) == 4
    assert long[(long["city"] == "Lucca") & (long["month"] == "feb")]["amount"].tolist() == [210]
