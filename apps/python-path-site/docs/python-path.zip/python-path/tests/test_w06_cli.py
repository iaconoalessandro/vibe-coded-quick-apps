import logging
import subprocess
import sys
from pathlib import Path

import pytest

from exercises.w06_cli import build_parser, log_level, main, percent_change, safe_ratio

ROOT = Path(__file__).parent.parent
SALES = ROOT / "practice_data" / "sales.arff"


def test_parser_defaults():
    args = build_parser().parse_args(["in.arff"])
    assert args.input == Path("in.arff")
    assert args.out_dir == Path("out")
    assert args.batch_size == 1000
    assert args.dry_run is False and args.verbose == 0


def test_parser_options():
    args = build_parser().parse_args(["x.arff", "--out-dir", "o", "--batch-size", "50", "--dry-run", "-vv"])
    assert args.out_dir == Path("o") and args.batch_size == 50 and args.dry_run and args.verbose == 2


def test_parser_rejects_bad_batch_size():
    with pytest.raises(SystemExit):
        build_parser().parse_args(["x.arff", "--batch-size", "many"])


def test_log_level():
    assert log_level(0) == logging.WARNING
    assert log_level(1) == logging.INFO
    assert log_level(2) == logging.DEBUG == log_level(5)


def test_main_writes_tables(tmp_path, capsys):
    assert main([str(SALES), "--out-dir", str(tmp_path / "star"), "-v"]) == 0
    assert sorted(p.name for p in (tmp_path / "star").iterdir()) == [
        "dim_date.csv", "dim_store.csv", "dim_title.csv", "fact_sales.csv",
    ]
    assert "fact_sales: 21 rows" in capsys.readouterr().err  # logging writes to stderr


def test_main_dry_run_writes_nothing(tmp_path, capsys):
    assert main([str(SALES), "--out-dir", str(tmp_path / "star"), "--dry-run", "-v"]) == 0
    assert not (tmp_path / "star").exists()
    assert "dry run" in capsys.readouterr().err


def test_main_missing_input(tmp_path, capsys):
    assert main([str(tmp_path / "nope.arff")]) == 1
    assert "nope.arff" in capsys.readouterr().err


def test_runs_as_a_program(tmp_path):
    # the real thing: a separate Python process, exactly like you'd run it in the terminal
    result = subprocess.run(
        [sys.executable, "-m", "exercises.w06_cli", str(SALES), "--out-dir", str(tmp_path), "-v"],
        cwd=ROOT, capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr
    assert (tmp_path / "fact_sales.csv").exists()


def test_safe_ratio_and_percent_change():
    assert safe_ratio(1, 4) == 0.25
    assert safe_ratio(5, 0) is None and safe_ratio(5, None) is None
    assert percent_change(80, 100) == 25.0
    assert percent_change(100, 80) == -20.0
    assert percent_change(3, 4) == 33.33
    assert percent_change(0, 10) is None
