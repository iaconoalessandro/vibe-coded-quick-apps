from exercises.w00_setup import average_of_positive, hello, in_virtualenv, python_version


def test_hello():
    assert hello("Ada") == "Hello, Ada!"
    assert hello("") == "Hello, !"


def test_python_version_format():
    major, minor = python_version().split(".")
    assert major == "3" and minor.isdigit()


def test_running_inside_venv():
    # fails if you run pytest from conda's (base) or system Python: activate .venv first
    assert in_virtualenv() is True


def test_average_of_positive():
    assert average_of_positive([2, -1, 4]) == 3.0
    assert average_of_positive([5]) == 5.0
    assert average_of_positive([1, 2, 3, 4]) == 2.5


def test_average_of_positive_no_positives():
    assert average_of_positive([]) == 0.0
    assert average_of_positive([-3, 0, -1]) == 0.0
