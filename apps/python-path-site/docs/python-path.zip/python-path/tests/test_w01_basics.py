import pytest

from exercises.w01_basics import (
    celsius_to_fahrenheit,
    collatz_steps,
    count_digits,
    count_vowels,
    first_index_above,
    fizzbuzz,
    format_price,
    grade,
    initials,
    is_even,
    is_palindrome,
    multiplication_table,
    reverse_words,
    safe_int,
    sum_to,
)


def test_celsius_to_fahrenheit():
    assert celsius_to_fahrenheit(100) == 212
    assert celsius_to_fahrenheit(0) == 32
    assert celsius_to_fahrenheit(-40) == -40
    assert celsius_to_fahrenheit(37) == pytest.approx(98.6)  # floats are never exact


def test_is_even():
    assert is_even(4) and is_even(0) and is_even(-2)
    assert not is_even(7)


@pytest.mark.parametrize("score,letter", [(100, "A"), (90, "A"), (89, "B"), (80, "B"), (75, "C"), (69, "F"), (0, "F")])
def test_grade(score, letter):
    assert grade(score) == letter


def test_grade_rejects_out_of_range():
    with pytest.raises(ValueError):
        grade(101)
    with pytest.raises(ValueError):
        grade(-1)


def test_sum_to():
    assert sum_to(0) == 0
    assert sum_to(1) == 1
    assert sum_to(100) == 5050


def test_count_vowels():
    assert count_vowels("Hello World") == 3
    assert count_vowels("AEIOU aeiou") == 10
    assert count_vowels("rhythm") == 0
    assert count_vowels("") == 0


def test_fizzbuzz():
    assert fizzbuzz(5) == ["1", "2", "Fizz", "4", "Buzz"]
    assert fizzbuzz(15)[-1] == "FizzBuzz"
    assert fizzbuzz(0) == []


def test_reverse_words():
    assert reverse_words("  data   engineering is fun ") == "fun is engineering data"
    assert reverse_words("one") == "one"
    assert reverse_words("") == ""


def test_format_price():
    assert format_price(12.5) == "12.50 EUR"
    assert format_price(3, "USD") == "3.00 USD"
    assert format_price(2.999) == "3.00 EUR"


def test_initials():
    assert initials("ada  king lovelace") == "A.K.L."
    assert initials("Guido") == "G."


def test_is_palindrome():
    assert is_palindrome("A man, a plan, a canal: Panama")
    assert is_palindrome("")
    assert not is_palindrome("python")


def test_collatz_steps():
    assert collatz_steps(1) == 0
    assert collatz_steps(6) == 8
    assert collatz_steps(27) == 111
    with pytest.raises(ValueError):
        collatz_steps(0)


def test_first_index_above():
    assert first_index_above([1, 5, 3, 9], 4) == 1
    assert first_index_above([1, 2], 10) == -1
    assert first_index_above([], 0) == -1


def test_safe_int():
    assert safe_int("42") == 42
    assert safe_int(" 7 ") == 7
    assert safe_int("4.2", default=-1) == -1
    assert safe_int("abc") == 0


def test_count_digits():
    assert count_digits(0) == 1
    assert count_digits(7) == 1
    assert count_digits(-1234) == 4
    assert count_digits(10**9) == 10


def test_multiplication_table():
    assert multiplication_table(3) == "   1   2   3\n   2   4   6\n   3   6   9"
    assert multiplication_table(1) == "   1"
