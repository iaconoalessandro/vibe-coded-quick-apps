"""Week 2: data structures (book ch. 9, 11-14, 27 "collections").

Lists, tuples, dicts, sets, mutability, nesting, comprehensions, sorting, recursion.
A table of data in plain Python is a LIST OF DICTS: one dict per row, keys are column names.
    rows = [{"store": "A", "qty": 5}, {"store": "B", "qty": 3}]
Most ETL code is loops over that shape: you will use it for the whole DSS project.
Run:  pytest tests/test_w02_collections.py -v
"""
from collections import Counter, defaultdict


# ---------- lists & tuples ----------

def second_largest(nums):
    """Return the second largest DISTINCT value, or None if there isn't one.

    >>> second_largest([3, 9, 9, 1])
    3
    """
    raise NotImplementedError  # TODO: your code here


def unique_in_order(items):
    """Remove duplicates, keeping the first occurrence and the original order.

    >>> unique_in_order(["b", "a", "b", "c", "a"])
    ['b', 'a', 'c']
    Hint: a set `seen` for O(1) membership checks, a list for the order.
    """
    raise NotImplementedError  # TODO: your code here


def append_copy(lst, item):
    """Return a NEW list with item appended. The original list must NOT change.

    Aliasing trap: `new = lst` does not copy. Why does the test check `lst` afterwards?
    """
    raise NotImplementedError  # TODO: your code here


def min_max(nums):
    """Return a tuple (smallest, largest) in one pass, without min() or max().

    Raise ValueError on an empty list. Tuples are how Python returns several values.
    """
    raise NotImplementedError  # TODO: your code here


def transpose(matrix):
    """Transpose a list of lists using a nested list comprehension.

    >>> transpose([[1, 2, 3], [4, 5, 6]])
    [[1, 4], [2, 5], [3, 6]]
    """
    raise NotImplementedError  # TODO: your code here


def squares_of_odds(nums):
    """One list comprehension: the squares of the odd numbers, in order.

    >>> squares_of_odds([1, 2, 3, 4, 5])
    [1, 9, 25]
    """
    raise NotImplementedError  # TODO: your code here


# ---------- dicts & sets ----------

def word_frequencies(text):
    """Count words, case-insensitive, ignoring the punctuation .,!?;: around words.

    >>> word_frequencies("The cat. The DOG!")
    {'the': 2, 'cat': 1, 'dog': 1}
    Do it once with a plain dict and dict.get(word, 0), then rewrite with Counter.
    """
    raise NotImplementedError  # TODO: your code here


def top_n(freqs, n):
    """Return the n (word, count) pairs with the highest counts as a list of tuples.

    Ties are broken alphabetically. Hint: sorted(freqs.items(), key=lambda kv: (-kv[1], kv[0]))
    """
    raise NotImplementedError  # TODO: your code here


def invert_dict(d):
    """Map each value to the sorted list of keys that had it.

    >>> invert_dict({"a": 1, "b": 2, "c": 1})
    {1: ['a', 'c'], 2: ['b']}
    """
    raise NotImplementedError  # TODO: your code here


def merge_counts(a, b):
    """Return a new dict with the counts of a and b added together. Do not modify a or b."""
    raise NotImplementedError  # TODO: your code here


def common_and_only(a, b):
    """Return a tuple of three SORTED lists: (in both, only in a, only in b).

    Hint: set operators & and -
    """
    raise NotImplementedError  # TODO: your code here


# ---------- rows: the ETL shape ----------

def column(rows, key):
    """Return the list of values for one column. Rows missing the key give None.

    >>> column([{"a": 1}, {"b": 2}], "a")
    [1, None]
    """
    raise NotImplementedError  # TODO: your code here


def group_by(rows, key):
    """Group rows into a dict: value of `key` -> list of the rows with that value.

    Keep row order inside each group. This is SQL's GROUP BY, by hand.
    """
    raise NotImplementedError  # TODO: your code here


def aggregate(rows, group_key, value_key, how="sum"):
    """GROUP BY group_key and aggregate value_key. `how` is "sum", "count", "mean" or "max".

    Return a dict group -> number. Raise ValueError for an unknown `how`.
    >>> aggregate([{"s": "A", "q": 2}, {"s": "A", "q": 4}, {"s": "B", "q": 1}], "s", "q", "mean")
    {'A': 3.0, 'B': 1.0}
    """
    raise NotImplementedError  # TODO: your code here


def index_by(rows, key):
    """Build a lookup dict key value -> row. Raise ValueError if a key value repeats.

    This is how you join two tables in plain Python: index one, loop over the other.
    """
    raise NotImplementedError  # TODO: your code here


def join(left, right, key):
    """Inner join two lists of rows on `key`. Return new merged dicts (left fields first).

    Use index_by on `right`, then one loop over `left`: O(n + m), not O(n * m).
    """
    raise NotImplementedError  # TODO: your code here


def sales_summary(rows):
    """Mini-project. rows look like {"store": "S1", "title": "T1", "qty": 5}.

    Return {store: {"orders": n_rows, "qty": total_qty, "top_title": title_with_most_qty}}
    Ties for top_title -> the alphabetically first title.
    Combine group_by, sum and a Counter (Counter.most_common is useful but check its tie order!).
    """
    raise NotImplementedError  # TODO: your code here


# ---------- recursion (you know the theory: now the Python) ----------

def flatten(nested):
    """Flatten arbitrarily nested lists.

    >>> flatten([1, [2, [3, [4]], 5]])
    [1, 2, 3, 4, 5]
    Hint: isinstance(x, list)
    """
    raise NotImplementedError  # TODO: your code here


def depth(nested):
    """Max nesting depth: depth([]) is 1, depth([1, [2, [3]]]) is 3. Recursive."""
    raise NotImplementedError  # TODO: your code here


def binary_search(sorted_list, target, lo=0, hi=None):
    """Recursive binary search. Return the index of target or -1.

    Default argument hi=None, then set hi = len(sorted_list) - 1 on the first call.
    Never use a mutable default like hi=[]: why? (see the cheat sheet)
    """
    raise NotImplementedError  # TODO: your code here


def merge_sort(nums):
    """Recursive merge sort returning a NEW sorted list. Don't use sort() or sorted()."""
    raise NotImplementedError  # TODO: your code here
