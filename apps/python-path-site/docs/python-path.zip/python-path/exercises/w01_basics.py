"""Week 1: core syntax (book ch. 3-8 and 10).

Variables, types, expressions, strings, conditions, loops, functions.
Rule for this week: only plain loops and if/else. No list comprehensions yet; they come in week 2.
Run:  pytest tests/test_w01_basics.py -v
"""


def celsius_to_fahrenheit(celsius):
    """Convert Celsius to Fahrenheit: F = C * 9/5 + 32.

    >>> celsius_to_fahrenheit(100)
    212.0
    """
    raise NotImplementedError  # TODO: your code here


def is_even(n):
    """Return True if the integer n is even. Hint: the % operator."""
    raise NotImplementedError  # TODO: your code here


def grade(score):
    """Turn a score 0-100 into a letter: >=90 "A", >=80 "B", >=70 "C", otherwise "F".

    Raise ValueError if score is outside 0..100 (e.g. `raise ValueError("bad score")`).
    Order of the if/elif branches matters: why?
    """
    raise NotImplementedError  # TODO: your code here


def sum_to(n):
    """Return 1 + 2 + ... + n using a loop (not the formula). sum_to(0) is 0."""
    raise NotImplementedError  # TODO: your code here


def count_vowels(text):
    """Count the vowels (a, e, i, o, u, upper or lower case) in text.

    >>> count_vowels("Hello World")
    3
    """
    raise NotImplementedError  # TODO: your code here


def fizzbuzz(n):
    """Return a list of strings for 1..n: "Fizz" for multiples of 3, "Buzz" for 5,
    "FizzBuzz" for both, otherwise the number as a string.

    >>> fizzbuzz(5)
    ['1', '2', 'Fizz', '4', 'Buzz']
    """
    raise NotImplementedError  # TODO: your code here


def reverse_words(sentence):
    """Reverse the order of words. Extra spaces between words collapse to one.

    >>> reverse_words("  data   engineering is fun ")
    'fun is engineering data'
    Hint: str.split() with no argument, slicing [::-1], " ".join(...)
    """
    raise NotImplementedError  # TODO: your code here


def format_price(amount, currency="EUR"):
    """Format a number with exactly 2 decimals followed by the currency.

    >>> format_price(12.5)
    '12.50 EUR'
    >>> format_price(3, "USD")
    '3.00 USD'
    Hint: f-string format spec  f"{x:.2f}"
    """
    raise NotImplementedError  # TODO: your code here


def initials(full_name):
    """Return the capitalised initials, each followed by a dot.

    >>> initials("ada  king lovelace")
    'A.K.L.'
    """
    raise NotImplementedError  # TODO: your code here


def is_palindrome(text):
    """True if text reads the same backwards, ignoring case and anything that is not a letter.

    >>> is_palindrome("A man, a plan, a canal: Panama")
    True
    Hint: str.isalpha()
    """
    raise NotImplementedError  # TODO: your code here


def collatz_steps(n):
    """Count the steps to reach 1: if n is even n = n // 2, else n = 3n + 1.

    collatz_steps(1) is 0, collatz_steps(6) is 8. Use a while loop.
    Raise ValueError for n < 1.
    """
    raise NotImplementedError  # TODO: your code here


def first_index_above(values, threshold):
    """Return the index of the first value > threshold, or -1 if none.

    Practise `for i, v in enumerate(values)` and returning early from inside a loop.
    """
    raise NotImplementedError  # TODO: your code here


def safe_int(text, default=0):
    """Convert text to int; if that fails, return default.

    >>> safe_int("42")
    42
    >>> safe_int(" 7 ")
    7
    >>> safe_int("4.2", default=-1)
    -1
    Preview of week 3: try / except ValueError.
    """
    raise NotImplementedError  # TODO: your code here


def count_digits(n):
    """Count the digits of an integer (sign ignored) without converting it to str.

    count_digits(0) is 1, count_digits(-1234) is 4. Use a while loop and // 10.
    """
    raise NotImplementedError  # TODO: your code here


def multiplication_table(n):
    """Return the n x n table as one string: rows separated by newlines, numbers
    right-aligned in width 4.

    >>> print(multiplication_table(3))
       1   2   3
       2   4   6
       3   6   9
    Hint: nested loops and f"{x:4d}"
    """
    raise NotImplementedError  # TODO: your code here
