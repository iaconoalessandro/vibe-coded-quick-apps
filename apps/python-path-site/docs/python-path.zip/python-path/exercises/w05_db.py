"""Week 5: databases from Python (book ch. 23 "Iterators and Generators" + DB-API).

You practise on sqlite3 (built into Python, no server). pyodbc for SQL Server follows the SAME
DB-API: connect -> cursor -> execute/executemany with ? placeholders -> commit -> fetch.
So everything here carries over to your Group_ID_DB, with one difference: on pyodbc
set `cursor.fast_executemany = True` before executemany, or bulk inserts crawl.
Run:  pytest tests/test_w05_db.py -v
"""
import csv
import json
from pathlib import Path


def batched(iterable, n):
    """Generator: yield lists of up to n items from any iterable (even a generator).

    >>> list(batched(range(5), 2))
    [[0, 1], [2, 3], [4]]
    Raise ValueError if n < 1. Uses `yield`: nothing is computed until someone asks.
    """
    raise NotImplementedError  # TODO: your code here


def iter_csv_rows(path):
    """Generator: yield one dict per CSV row (header in first line) without loading the file in memory."""
    raise NotImplementedError  # TODO: your code here


def create_star_schema(conn):
    """Create the 4 tables of week 4's sales star schema (drop them first if they exist).

    dim_store(store_key INTEGER PRIMARY KEY, stor_id TEXT NOT NULL UNIQUE)
    dim_title(title_key INTEGER PRIMARY KEY, title_id TEXT NOT NULL UNIQUE)
    dim_date(date_id INTEGER PRIMARY KEY, date TEXT, day INTEGER, month INTEGER, year INTEGER,
             quarter INTEGER, weekday TEXT, season TEXT)
    fact_sales(ord_num TEXT, store_key INTEGER REFERENCES dim_store, title_key INTEGER REFERENCES dim_title,
               date_id INTEGER REFERENCES dim_date, payterms TEXT, qty INTEGER)
    Hint: conn.executescript("...several statements;...")
    """
    raise NotImplementedError  # TODO: your code here


def insert_rows(conn, table, rows, batch_size=500):
    """Insert an iterable of dicts into `table` with executemany, batch_size rows at a time.

    Column names come from the first row. Return the number of rows inserted.
    VALUES must use ? placeholders, never f-strings with values (SQL injection + quoting bugs).
    Table/column NAMES can't be placeholders, so check each with str.isidentifier() and
    raise ValueError if one isn't. Commit once at the end.
    """
    raise NotImplementedError  # TODO: your code here


def load_star_from_csv(conn, csv_dir):
    """Create the schema and load dim_store, dim_title, dim_date, fact_sales from csv_dir/<table>.csv.

    Dimensions first, then the fact: why does the order matter? Return {table: n_rows}.
    Stream the CSVs with iter_csv_rows: don't build lists.
    """
    raise NotImplementedError  # TODO: your code here


def qty_by_store(conn):
    """SQL: total qty per store as a list of (stor_id, total) tuples, biggest total first, ties by stor_id."""
    raise NotImplementedError  # TODO: your code here


def qty_by_year_season(conn):
    """SQL: list of (year, season, total_qty) ordered by year then season name."""
    raise NotImplementedError  # TODO: your code here


def export_query_to_json(conn, sql, path, params=(), chunk_size=1000):
    """Run sql and stream the result to a JSON array of objects at path. Return the row count.

    Fetch with cursor.fetchmany(chunk_size) in a loop so a huge result never sits in memory;
    column names are in cursor.description (first item of each entry). Write "[", rows separated
    by ",", then "]" yourself: json.dump on a full list would need all rows in memory.
    """
    raise NotImplementedError  # TODO: your code here


def db_settings(environ):
    """Read DB_SERVER, DB_NAME, DB_USER, DB_PASSWORD from a mapping (pass os.environ in real code).

    Return {"server", "database", "user", "password"}. If any are missing raise KeyError whose
    message lists ALL missing names. Credentials live in the environment / .env, never in code or git.
    """
    raise NotImplementedError  # TODO: your code here


def sqlserver_connection_string(settings, driver="ODBC Driver 18 for SQL Server"):
    """Build the pyodbc connection string from db_settings(...) output:

    "DRIVER={ODBC Driver 18 for SQL Server};SERVER=s;DATABASE=d;UID=u;PWD=p;TrustServerCertificate=yes"
    Then in real code: pyodbc.connect(sqlserver_connection_string(db_settings(os.environ)))
    """
    raise NotImplementedError  # TODO: your code here
