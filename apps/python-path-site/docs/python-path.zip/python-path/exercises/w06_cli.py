"""Week 6: turn functions into a real program (book ch. 24 "Command Line Processing").

argparse for options, logging instead of print, exit codes, and a main() that wires weeks 3-4 together.
When it's done you can run:
    python -m exercises.w06_cli practice_data/sales.arff --out-dir out/star -v
That is the shape every DSS script should have.
Run:  pytest tests/test_w06_cli.py -v
"""
import argparse
import logging
import sys
from pathlib import Path

from exercises.w03_files import parse_arff
from exercises.w04_cleaning import build_sales_star, write_tables

log = logging.getLogger(__name__)


def build_parser():
    """Return an argparse.ArgumentParser(prog="sales2star") with:

    input            positional, the .arff file (type=Path)
    --out-dir        type=Path, default Path("out")
    --batch-size     int, default 1000
    --dry-run        flag (store_true): compute but write nothing
    -v / --verbose   count: -v is INFO, -vv is DEBUG
    """
    raise NotImplementedError  # TODO: your code here


def log_level(verbosity):
    """0 -> logging.WARNING, 1 -> logging.INFO, 2 or more -> logging.DEBUG."""
    raise NotImplementedError  # TODO: your code here


def main(argv=None):
    """Program entry point. Return an exit code: 0 ok, 1 error.

    1. parse argv with build_parser(); configure logging with
       logging.basicConfig(level=log_level(args.verbose), format="%(levelname)s %(message)s", force=True)
    2. if the input file doesn't exist: log.error(...) mentioning the path, return 1
    3. parse_arff -> build_sales_star; log.info one line per table: "<table>: <n> rows"
    4. if --dry-run: log.info("dry run: nothing written"), return 0
    5. otherwise write_tables(star, args.out_dir); log.info where; return 0
    """
    raise NotImplementedError  # TODO: your code here


def safe_ratio(numerator, denominator):
    """numerator / denominator, or None when the denominator is 0 or None (never crash, never fake a 0)."""
    raise NotImplementedError  # TODO: your code here


def percent_change(old, new):
    """Percentage change from old to new, rounded to 2 decimals. None when old is 0 or None.

    >>> percent_change(80, 100)
    25.0
    """
    raise NotImplementedError  # TODO: your code here


if __name__ == "__main__":
    sys.exit(main())
