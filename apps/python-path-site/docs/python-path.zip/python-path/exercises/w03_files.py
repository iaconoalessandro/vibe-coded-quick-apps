"""Week 3: files, formats, exceptions (book ch. 15-17 and 26).

Every reader here returns the same shape: a LIST OF DICTS (week 2), so the rest of your
pipeline never cares whether the data came from CSV, ARFF, XML or JSON.
Practice files are in practice_data/ (the DSS lab files + loans.json).
Rules: always `with open(...)`, always encoding="utf-8", always newline="" for csv files.
Run:  pytest tests/test_w03_files.py -v
"""
import csv
import json
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

MISSING = {"", "?"}  # ARFF writes missing values as "?"


def count_lines(path):
    """Return the number of lines in a text file. Iterate over the file object: never .read() a big file."""
    raise NotImplementedError  # TODO: your code here


def read_header_file(path):
    """Read a one-line comma-separated header file (practice_data/census.header) into a list of names."""
    raise NotImplementedError  # TODO: your code here


def read_csv_rows(path, fieldnames=None):
    """Read a CSV into a list of dicts with csv.DictReader. Values stay strings.

    If fieldnames is None the first line is the header; otherwise use the given names
    (census_selected.csv has no header: its names are in census.header).
    Strip surrounding spaces from every value.
    """
    raise NotImplementedError  # TODO: your code here


def write_csv(rows, path, fieldnames):
    """Write rows (list of dicts) to a CSV with a header line; create parent folders if needed.

    Return the number of data rows written. Hint: Path(path).parent.mkdir(parents=True, exist_ok=True)
    """
    raise NotImplementedError  # TODO: your code here


def to_number(value):
    """Convert a raw string to int or float when possible.

    "42" -> 42, " 3.5 " -> 3.5, "?" or "" or "  " -> None, "Private" -> "Private" (stripped).
    Use try/except ValueError: don't try to detect digits by hand.
    """
    raise NotImplementedError  # TODO: your code here


def convert_types(rows):
    """Return NEW rows with to_number applied to every value."""
    raise NotImplementedError  # TODO: your code here


def missing_report(rows):
    """Return {field: number of missing values} for fields with at least one missing.

    Missing means None, or a string that is "" or "?" after stripping.
    """
    raise NotImplementedError  # TODO: your code here


def parse_arff(path):
    """Parse a simple ARFF file into {"relation": str, "attributes": [(name, type)], "rows": [dict]}.

    Format: lines starting with % are comments; @relation NAME; @attribute NAME TYPE
    (TYPE may contain spaces, e.g. "date 'yyyy-MM-dd'" or "{a, b}"); then @data, then one CSV
    line per row where text values may be wrapped in single quotes: 'Net 60'.
    Keywords are case-insensitive (@DATA works too). Row values are strings without the quotes.

    Hint: str.split(maxsplit=2), and csv.reader(lines, quotechar="'", skipinitialspace=True).
    Think: what would break if a text value contained a comma? an apostrophe? double quotes?
    """
    raise NotImplementedError  # TODO: your code here


def xml_attribute_rows(path, record_tag="row"):
    """census_row.xml stores each record as attributes: <row id="1" age="39" .../>.

    Return a list of dicts (attribute name -> string value), one per <record_tag> element.
    Hint: ET.parse(path).getroot().iter(record_tag) and element.attrib
    """
    raise NotImplementedError  # TODO: your code here


def xml_element_rows(path, record_tag):
    """census_elements.xml stores each record as child elements: <census><id>1</id><age>39</age>...</census>.

    Return a list of dicts child tag -> text ("" if the element is empty).
    """
    raise NotImplementedError  # TODO: your code here


def count_values_streaming(path, record_tag, field):
    """Count the values of child `field` across all <record_tag> elements WITHOUT loading the whole tree.

    Use ET.iterparse(path, events=("end",)) and call elem.clear() after each finished record,
    so memory stays flat even on a multi-GB file. Return a plain dict value -> count.
    """
    raise NotImplementedError  # TODO: your code here


def load_json(path):
    """Load a JSON file and return the Python object."""
    raise NotImplementedError  # TODO: your code here


def save_json(obj, path):
    """Save obj as pretty JSON (indent=2, ensure_ascii=False so "è" stays readable). Create parent folders."""
    raise NotImplementedError  # TODO: your code here


def borrows_per_member(path):
    """loans.json has "members" and "events". Count the events of type "borrow" per member NAME.

    Skip events whose member_id is missing (None) or unknown. Return {name: count},
    only for members with at least one borrow. Duplicated events count twice (cleaning is week 4).
    """
    raise NotImplementedError  # TODO: your code here


def read_text_safely(path):
    """Return the file's text, or None if the file does not exist.

    If the bytes are not valid UTF-8, don't crash: decode with errors="replace" (bad bytes become "�").
    Catch the specific exceptions (FileNotFoundError, UnicodeDecodeError), never a bare `except:`.
    """
    raise NotImplementedError  # TODO: your code here
