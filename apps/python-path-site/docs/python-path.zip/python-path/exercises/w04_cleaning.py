"""Week 4: dates, data quality, text, star schema (book ch. 8 "Modules", 25, 27).

This file IMPORTS your week-3 code: that's what modules are for. Write a function once, reuse it.
The last two exercises turn practice_data/sales.arff into a small star schema
(dimensions + fact table, one CSV per table): the same kind of job as DSS Assignments 3-4,
on different data.
Run:  pytest tests/test_w04_cleaning.py -v
"""
import re
import statistics
from datetime import datetime
from pathlib import Path

from exercises.w03_files import write_csv

WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


# ---------- dates ----------

def parse_timestamp(text):
    """Parse "1994-09-14 08:30:00" or "1994-09-14T08:30:00" into a datetime.

    Raise ValueError for anything else (that's what datetime does by default: let it propagate).
    Hint: datetime.fromisoformat, or datetime.strptime(text, "%Y-%m-%d %H:%M:%S").
    """
    raise NotImplementedError  # TODO: your code here


def season(dt):
    """Meteorological season: Dec-Feb "winter", Mar-May "spring", Jun-Aug "summer", Sep-Nov "autumn"."""
    raise NotImplementedError  # TODO: your code here


def date_dimension_row(dt):
    """Return one row of a date dimension:

    {"date_id": 19940914, "date": "1994-09-14", "day": 14, "month": 9, "year": 1994,
     "quarter": 3, "weekday": "Wednesday", "season": "autumn"}
    date_id is an int YYYYMMDD: a common surrogate key for dates. Use WEEKDAYS and dt.weekday().
    """
    raise NotImplementedError  # TODO: your code here


def hours_between(start, end):
    """Hours (float) from timestamp string start to end; negative if end is earlier.

    Subtracting two datetimes gives a timedelta: use .total_seconds().
    """
    raise NotImplementedError  # TODO: your code here


# ---------- data quality ----------

def row_key(row, key_fields):
    """Return a hashable identity for a row, so rows can go in a set or be dict keys.

    key_fields=None -> the whole row: tuple(sorted(row.items())).
    Otherwise the tuple of the values of key_fields, in that order.
    >>> row_key({"b": 2, "a": 1}, None)
    (('a', 1), ('b', 2))
    >>> row_key({"b": 2, "a": 1}, ["b"])
    (2,)
    """
    raise NotImplementedError  # TODO: your code here


def find_duplicates(rows, key_fields):
    """Return the key tuples that occur more than once, each listed once, in first-seen order.

    >>> find_duplicates([{"a": 1, "b": 2}, {"a": 1, "b": 3}, {"a": 1, "b": 2}], ["a", "b"])
    [(1, 2)]
    """
    raise NotImplementedError  # TODO: your code here


def drop_duplicates(rows, key_fields=None):
    """Return rows without duplicates, keeping the first occurrence.

    key_fields=None means "the whole row must match". Hint: tuple(sorted(row.items()))
    turns a dict into something you can put in a set.
    """
    raise NotImplementedError  # TODO: your code here


def mean_std(values):
    """Return (mean, sample standard deviation) ignoring None values.

    No values -> (None, None). One value -> (value, 0.0). Use the statistics module.
    Edge cases like these are exactly what graders check: decide them, then document them.
    """
    raise NotImplementedError  # TODO: your code here


def zscore_outliers(values, k=3.0):
    """Return the indexes of values farther than k standard deviations from the mean.

    None values are never outliers. If std is 0 (or undefined) there are no outliers.
    """
    raise NotImplementedError  # TODO: your code here


# ---------- text ----------

def clean_text(text):
    """Collapse all runs of whitespace (spaces, tabs, newlines) to one space and strip. None -> ""."""
    raise NotImplementedError  # TODO: your code here


def extract_hashtags(text):
    """Return the hashtags in order, lowercased, without '#'.

    >>> extract_hashtags("Go #Python and #DataEng! #python")
    ['python', 'dataeng', 'python']
    Hint: re.findall(r"#(\\w+)", text)
    """
    raise NotImplementedError  # TODO: your code here


def extract_urls(text):
    """Return the http/https URLs in the text, without trailing . , ) ! ? characters."""
    raise NotImplementedError  # TODO: your code here


def categorize(text, rules, default="other"):
    """Rule-based classifier. rules is an ordered dict category -> list of keywords.

    Return the FIRST category with a keyword appearing in text as a whole word,
    case-insensitive ("art" must not match "start"). No match -> default.
    Hint: re.search(rf"\\b{re.escape(word)}\\b", text, re.IGNORECASE)
    """
    raise NotImplementedError  # TODO: your code here


# ---------- star schema ----------

def build_dimension(rows, fields, key_name):
    """Build a dimension table from the distinct combinations of `fields`.

    Return (dim_rows, lookup):
      dim_rows: [{key_name: 1, field1: ..., field2: ...}, ...]  surrogate keys 1, 2, 3... in first-seen order
      lookup:   {(value1, value2): 1, ...}  so fact rows can find their key in O(1)
    """
    raise NotImplementedError  # TODO: your code here


def build_sales_star(rows):
    """Turn parse_arff("sales.arff")["rows"] into a star schema.

    Return {"dim_store": [...], "dim_title": [...], "dim_date": [...], "fact_sales": [...]} where
      dim_store: {"store_key", "stor_id"}        (build_dimension)
      dim_title: {"title_key", "title_id"}       (build_dimension)
      dim_date:  date_dimension_row(...) rows, one per distinct date, sorted by date_id
      fact_sales: one per input row, in input order:
        {"ord_num", "store_key", "title_key", "date_id", "payterms", "qty"}  with qty as int
    """
    raise NotImplementedError  # TODO: your code here


def write_tables(tables, out_dir):
    """Write each table to out_dir/<name>.csv (header = keys of the first row). Return {name: n_rows}.

    Reuse write_csv from week 3.
    """
    raise NotImplementedError  # TODO: your code here
