"""Week 4+: NumPy and pandas, the one-line versions of weeks 2-4.

Install once in your venv:  pip install pandas   (NumPy comes with it)
Run:  pytest tests/test_w04p_pandas.py -v
"""
import numpy as np
import pandas as pd

MISSING_MARKERS = ["?", "unknown", "N/A", -999]


# ---------- NumPy ----------

def grid(n, cols):
    """The numbers 0..n-1 as a 2-D array with `cols` columns: grid(6, 3) -> [[0, 1, 2], [3, 4, 5]].

    Hint: np.arange, then .reshape(-1, cols).
    """
    raise NotImplementedError  # TODO: your code here


def column_stats(matrix):
    """Mean and population std of each COLUMN of a 2-D array, as a tuple of two arrays.

    Hint: axis=0 squashes the rows: one number per column.
    """
    raise NotImplementedError  # TODO: your code here


def min_max_scale(arr):
    """Rescale so the smallest value becomes 0.0 and the largest 1.0, without a loop.

    Hint: arr - arr.min() works on every element at once.
    """
    raise NotImplementedError  # TODO: your code here


def clip_negative(arr):
    """Replace every negative value with 0, keep the rest.

    Hint: np.where(condition, if_true, if_false).
    """
    raise NotImplementedError  # TODO: your code here


def count_in_range(arr, lo, hi):
    """How many values are >= lo and <= hi, as a plain int.

    Hint: a mask with & and parentheses; True counts as 1 in .sum().
    """
    raise NotImplementedError  # TODO: your code here


def grade_bands(scores):
    """>= 85 "A", >= 70 "B", >= 50 "C", otherwise "F", for each score.

    Hint: np.select(conditions, choices, default=...), strictest condition first.
    """
    raise NotImplementedError  # TODO: your code here


# ---------- inspect, select, filter ----------

def load_jobs(path):
    """Read practice_data/jobs.csv (no header row) with columns job_id, title, min_lvl, max_lvl.

    Hint: pd.read_csv(path, header=None, names=[...]).
    """
    raise NotImplementedError  # TODO: your code here


def profile(df):
    """{"rows": number of rows, "cols": number of columns, "missing": {column: missing count}}.

    Hint: df.shape, and df.isnull().sum() is a Series: .to_dict() turns it into a dict.
    """
    raise NotImplementedError  # TODO: your code here


def filter_orders(df, cities, lo, hi):
    """Rows whose city is in `cities` and whose amount is between lo and hi (both included).

    Hint: .isin(list) and .between(lo, hi), combined with &.
    """
    raise NotImplementedError  # TODO: your code here


def top_customers(df, n):
    """The n customers with the highest total amount, as a list of names, biggest first.

    Hint: groupby + sum, sort_values(ascending=False), .head(n), then the index is the names.
    """
    raise NotImplementedError  # TODO: your code here


# ---------- cleaning ----------

def clean_orders(df):
    """Clean a raw orders table:

    - column names stripped and lower-cased
    - every value in MISSING_MARKERS becomes NaN
    - rows without an order_id are dropped, exact duplicate rows too
    - missing qty becomes 0, then order_id and qty are ints
    - date becomes a datetime column

    Hint: rename(columns=function), replace(list, np.nan), dropna(subset=...), drop_duplicates,
    fillna, astype({col: int}), pd.to_datetime. Remember df = df.something().
    """
    raise NotImplementedError  # TODO: your code here


def latest_per_customer(df):
    """One row per customer: their most recent order (by date), sorted by customer.

    Hint: sort by date, then drop_duplicates(subset=[...], keep="last").
    """
    raise NotImplementedError  # TODO: your code here


def add_date_parts(df):
    """Return a copy of df with new columns year, month and weekday ("Monday", ...) from the date column.

    Hint: the .dt accessor: .dt.year, .dt.month, .dt.day_name().
    """
    raise NotImplementedError  # TODO: your code here


def tidy_posts(df):
    """Return a copy of df with text stripped and lower-cased, plus n_hashtags (count of "#word")
    and mentions_sale (True if the text contains "sale").

    Hint: the .str accessor: .str.strip(), .str.lower(), .str.count(regex), .str.contains(...).
    """
    raise NotImplementedError  # TODO: your code here


# ---------- new columns ----------

def add_size_band(df):
    """Return a copy of df with size: amount >= 200 "high", >= 100 "medium", otherwise "low".

    Hint: np.select works on columns too.
    """
    raise NotImplementedError  # TODO: your code here


def age_groups(ages):
    """Bin a Series of ages: (0, 18] "minor", (18, 65] "adult", (65, 120] "senior".

    Hint: pd.cut(series, bins=[...], labels=[...]).
    """
    raise NotImplementedError  # TODO: your code here


def one_hot(df, column):
    """Replace `column` with one 0/1 int column per value (named column_value).

    Hint: pd.get_dummies(df, columns=[...], dtype=int).
    """
    raise NotImplementedError  # TODO: your code here


# ---------- group, join, reshape ----------

def sales_by_city(df):
    """One row per city with columns city, total, orders, avg; biggest total first; index 0, 1, 2...

    Hint: groupby(...).agg(total=("amount", "sum"), ...), then reset_index(); after sorting,
    reset_index(drop=True) renumbers the rows.
    """
    raise NotImplementedError  # TODO: your code here


def add_share_of_city(df):
    """Return a copy of df with share: each order's amount divided by its city's total amount.

    Hint: groupby(...)["amount"].transform("sum") gives the city total on every row.
    """
    raise NotImplementedError  # TODO: your code here


def join_customers(orders, customers):
    """Left-join customer details onto orders by "customer". Raise if a customer appears twice in customers.

    Hint: pd.merge(..., how="left", validate="many_to_one").
    """
    raise NotImplementedError  # TODO: your code here


def stack_months(frames):
    """Stack a list of DataFrames with the same columns into one, renumbered 0, 1, 2...

    Hint: pd.concat(list, ignore_index=True).
    """
    raise NotImplementedError  # TODO: your code here


def monthly_pivot(df):
    """Total amount with one row per city and one column per month number; missing combinations are 0.

    Hint: pivot_table(index=..., columns=..., values=..., aggfunc=..., fill_value=0).
    """
    raise NotImplementedError  # TODO: your code here


def wide_to_long(df):
    """Turn columns city, jan, feb, ... into columns city, month, amount (one row per city-month).

    Hint: df.melt(id_vars=..., var_name=..., value_name=...).
    """
    raise NotImplementedError  # TODO: your code here
