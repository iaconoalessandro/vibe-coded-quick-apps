"""Week 0: prove your setup works.

Goal: write a .py file, run it, run its tests, use the debugger.
Run the tests with:   pytest tests/test_w00_setup.py
Run this file with:   python exercises/w00_setup.py
"""
import sys


def hello(name):
    """Return a greeting for `name`.

    >>> hello("Ada")
    'Hello, Ada!'
    """
    raise NotImplementedError  # TODO: your code here


def python_version():
    """Return the running Python version as "MAJOR.MINOR", e.g. "3.14".

    Hint: `sys.version_info` has `.major` and `.minor` attributes.
    """
    raise NotImplementedError  # TODO: your code here


def in_virtualenv():
    """Return True if this code is running inside a virtual environment.

    Hint: inside a venv, `sys.prefix` (the venv) differs from `sys.base_prefix`
    (the Python it was created from).
    """
    raise NotImplementedError  # TODO: your code here


def average_of_positive(numbers):
    """Return the average of the numbers that are > 0. Return 0.0 if there are none.

    DEBUGGING EXERCISE: this function is already written but has THREE bugs.
    1. Run the tests and read the traceback bottom-up: which line, which error?
    2. Put a breakpoint on the `for` line (click left of the line number),
       then Run > Start Debugging and step with F10. Watch `total` and `count`.
    Fix all three without rewriting the whole function.

    >>> average_of_positive([2, -1, 4])
    3.0
    """
    total = 0
    count = 0
    for n in numbers:
        if n > 0:
            total = n
        count += 1
    return total / count


if __name__ == "__main__":
    # runs only with `python exercises/w00_setup.py`, not when tests import this file
    print(hello("world"))
    print("Python", python_version(), "| in venv:", in_virtualenv())
