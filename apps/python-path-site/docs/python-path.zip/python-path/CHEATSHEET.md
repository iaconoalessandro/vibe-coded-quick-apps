# Python + Data Engineering cheat sheet

Search it in VS Code with `cmd+F`, or from the terminal: `grep -n -A5 "DictReader" CHEATSHEET.md`

---

## 1. Terminal (macOS zsh)
| Do | Command |
|---|---|
| where am I / list (incl. hidden) | `pwd` · `ls -la` |
| move / up / home / back | `cd folder` · `cd ..` · `cd ~` · `cd -` |
| make folder (nested) | `mkdir -p a/b/c` |
| copy / move-rename / delete | `cp a b` · `mv a b` · `rm file` (no trash, so be careful) |
| look at a file | `cat f` · `head -5 f` · `tail -5 f` · `less f` (q to quit) |
| count lines / search text | `wc -l f` · `grep -n "word" f` · `grep -rn "word" .` |
| autocomplete / history / stop | `Tab` · `↑` or `ctrl+R` · `ctrl+C` |
| open folder in VS Code / Finder | `code .` · `open .` |

Paths: `/Users/you/x` is absolute, `x/y.csv` is relative to `pwd`, `~` is home, `.` is here, `..` is the parent.
Quote paths with spaces: `cd "My Drive/01_Università"`.

## 2. Virtual environments & packages
```bash
python3 -m venv .venv            # once per project
source .venv/bin/activate        # every new terminal; `deactivate` to leave
which python                     # must end in .venv/bin/python
python -m pip install pytest pyodbc
python -m pip freeze > requirements.txt   # record versions
python -m pip install -r requirements.txt # recreate elsewhere
```
- One venv **per project**. Never `pip install` into conda `(base)` or the system Python.
- `.venv/` goes in `.gitignore`. Commit `requirements.txt` instead.
- VS Code: `cmd+shift+P` → *Python: Select Interpreter* → `.venv`.
- Later (Phase C): `uv venv`, `uv pip install`, `uv run`: the same ideas, 10–100× faster.

## 3. Git & GitHub
```bash
git init                          # new repo
git status                        # ALWAYS look before you commit
git add file.py   /   git add -A  # stage
git commit -m "w03: parse_arff handles quoted commas"
git log --oneline -10             # history
git diff                          # unstaged changes  (git diff --staged: staged)
git restore file.py               # throw away local changes to a file
git push / git pull               # sync with GitHub
gh auth login                     # once: log in GitHub CLI
gh repo create NAME --private --source=. --push   # publish this folder
git clone URL                     # copy a repo locally
```
Branches (Phase C, team work):
```bash
git switch -c fix-parser          # new branch
git push -u origin fix-parser     # publish it
gh pr create --fill               # open a pull request
git switch main && git pull       # back to main, up to date
```
- Commit small and often, with a message that says *what and why*.
- **Never commit** data files, `.env`, passwords, `.venv/`. Put them in `.gitignore` before the first commit.
- Committed a secret by accident? Change the password. Deleting the file doesn't remove it from history.

## 4. VS Code
| Do | Keys |
|---|---|
| command palette | `cmd+shift+P` |
| quick open file | `cmd+P` |
| terminal | `` ctrl+` `` |
| run file | ▶ top-right, or `python file.py` in terminal |
| debug | F5 · breakpoint: click left of line number · step over F10 · into F11 · continue F5 |
| go to definition / rename | F12 · F2 |
| comment line / multi-cursor | `cmd+/` · `opt+click` |
| search all files | `cmd+shift+F` |

## 5. Python core
```python
x = 42; y = 3.14; s = "text"; ok = True; nothing = None
type(x)  int("7")  float("2.5")  str(3)  bool("")   # False: "", 0, [], {}, None
7 / 2 == 3.5     7 // 2 == 3     7 % 2 == 1     2 ** 10 == 1024
x += 1           a, b = b, a     # swap
```
**Strings** (immutable):
```python
s = "  Data,Eng  "
s.strip() s.lower() s.upper() s.title() s.replace(",", ";")
s.split(",")  ",".join(["a", "b"])  s.startswith("Da")  "Eng" in s
s[0]  s[-1]  s[1:4]  s[::-1]  len(s)
f"{name} has {n} rows"  f"{price:.2f}"  f"{n:,}"  f"{x:>8}"  f"{x=}"  # last one: debug print
```
**Control flow**:
```python
if x > 0:  ...
elif x == 0:  ...
else:  ...
for i in range(5):        # 0..4        range(1, 6) -> 1..5    range(0, 10, 2)
for i, item in enumerate(items):
for a, b in zip(list1, list2):
while cond:  ... break / continue
value = "pos" if x > 0 else "neg"
```
**Functions**:
```python
def area(w, h=1):                 # h has a default
    """Docstring: what it does, args, return."""
    return w * h
area(3) area(3, h=2)
def f(*args, **kwargs): ...       # any positional / keyword args
```

## 6. Data structures
| | create | add | remove | lookup | notes |
|---|---|---|---|---|---|
| **list** `[]` | `[1, 2]` | `.append(x)` `.extend(l)` `.insert(i,x)` | `.pop()` `.remove(x)` `del l[i]` | `l[i]`, `x in l` is **O(n)** | ordered, mutable |
| **tuple** `()` | `(1, 2)` `1,` | no | no | `t[i]` | immutable, hashable → dict key / set item |
| **dict** `{}` | `{"a": 1}` `dict(a=1)` | `d[k] = v` `.update()` `.setdefault(k, [])` | `.pop(k)` `del d[k]` | `d[k]` (KeyError) · `d.get(k, default)` · `k in d` is **O(1)** | insertion-ordered |
| **set** | `set()` `{1, 2}` | `.add(x)` | `.discard(x)` | `x in s` is **O(1)** | unique, unordered · `a & b` `a \| b` `a - b` |

```python
for k, v in d.items(): ...        d.keys()  d.values()
sorted(rows, key=lambda r: (-r["qty"], r["name"]))   # desc qty, then name
[x * 2 for x in nums if x > 0]           # list comprehension
{r["id"]: r for r in rows}               # dict comprehension (index by id)
{r["city"] for r in rows}                # set comprehension (distinct)
from collections import Counter, defaultdict
Counter(words).most_common(3)            # top 3 (ties: first seen)
groups = defaultdict(list); groups[k].append(row)
```

## 7. The row pattern (ETL in plain Python)
A table is a **list of dicts**. Learn these 5 moves by heart:
```python
# 1 filter            (SQL WHERE)
big = [r for r in rows if r["qty"] > 10]
# 2 project / derive  (SQL SELECT)
out = [{"id": r["id"], "total": r["qty"] * r["price"]} for r in rows]
# 3 group + aggregate (SQL GROUP BY)
tot = defaultdict(int)
for r in rows: tot[r["store"]] += r["qty"]
# 4 join              (SQL JOIN): index one side, loop the other. O(n+m)
by_id = {u["id"]: u for u in users}
joined = [{**p, **by_id[p["user_id"]]} for p in posts if p["user_id"] in by_id]
# 5 distinct + surrogate keys (dimension table)
lookup = {}
for r in rows: lookup.setdefault(r["city"], len(lookup) + 1)
```

## 8. Files & formats
```python
from pathlib import Path
p = Path("data") / "file.csv"     p.exists()  p.name  p.suffix  p.parent.mkdir(parents=True, exist_ok=True)
for f in Path("data").glob("*.json"): ...

with open(p, encoding="utf-8") as f:          # text: ALWAYS with + encoding
    for line in f: ...                        # streams; f.read() loads it all
with open(p, "w", encoding="utf-8") as f: f.write("x\n")   # "a" = append
```
**CSV** (always `newline=""`):
```python
import csv
with open(p, encoding="utf-8", newline="") as f:
    rows = list(csv.DictReader(f))                 # header from first line, values are STRINGS
    # csv.DictReader(f, fieldnames=[...])          # file without header
    # csv.reader(f, delimiter=";", quotechar="'")  # lists instead of dicts
with open(p, "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["id", "name"]); w.writeheader(); w.writerows(rows)
```
**JSON**:
```python
import json
data = json.load(open(p, encoding="utf-8"))          # file -> dict/list
json.dump(obj, f, indent=2, ensure_ascii=False)       # dict/list -> file
json.loads(text)  json.dumps(obj)                     # string versions
# JSON Lines (.jsonl): one object per line -> stream it
for line in f: obj = json.loads(line)
```
**XML**:
```python
import xml.etree.ElementTree as ET
root = ET.parse(p).getroot()
for el in root.iter("row"):  el.attrib  el.get("id")  el.findtext("age")  el.text  list(el)
# big file: stream + free memory
for event, el in ET.iterparse(p, events=("end",)):
    if el.tag == "record": handle(el); el.clear()
```
**ARFF**: `% comment`, `@relation`, `@attribute name type`, `@data`, then CSV rows. `?` means missing.
Text values may be in `'single'` or `"double"` quotes, and they can contain commas. Test your parser on the nasty rows.

## 9. Exceptions
```python
try:
    n = int(text)
except ValueError:
    n = None
except (KeyError, IndexError) as e:
    log.warning("bad row: %s", e)
else:   ...   # ran only if no exception
finally: ...  # always runs
raise ValueError(f"bad score: {score}")
```
Catch the **specific** exception. A bare `except:` hides bugs. Common ones: `ValueError`, `KeyError`, `IndexError`, `TypeError`, `FileNotFoundError`, `UnicodeDecodeError`, `ZeroDivisionError`.
Reading a traceback: **start from the bottom line** (the error), then go up to the first line that is *your* file.

## 10. Dates & times
```python
from datetime import datetime, date, timedelta
dt = datetime.fromisoformat("2024-03-05 21:14:00")      # also accepts "T"
dt = datetime.strptime("05/03/2024 21:14", "%d/%m/%Y %H:%M")
dt.year dt.month dt.day dt.hour dt.weekday()  # Mon=0
dt.strftime("%Y-%m-%d")   dt.date()   dt + timedelta(days=7)
(dt2 - dt1).total_seconds() / 3600   # hours between
quarter = (dt.month - 1) // 3 + 1
date_id = dt.year * 10000 + dt.month * 100 + dt.day   # 20240305
```
`%Y` year · `%m` month · `%d` day · `%H` 24h · `%M` min · `%S` sec · `%A` weekday name · `%z` UTC offset.
Time zones: decide what "night" means (local vs UTC) and **document it**.

## 11. Regex (`import re`)
```python
re.findall(r"#(\w+)", text)                  # hashtags
re.findall(r"https?://\S+", text)            # URLs
re.search(rf"\b{re.escape(w)}\b", text, re.I)   # whole word, case-insensitive
re.sub(r"\s+", " ", text).strip()            # collapse whitespace
```
`\d` digit · `\w` word char · `\s` space · `\b` word boundary · `.` any · `*` 0+ · `+` 1+ · `?` 0/1 · `( )` group · `[abc]` set. Always use raw strings `r"..."`.

## 12. Stats without pandas
```python
import statistics as st
st.mean(v) st.median(v) st.stdev(v)  # sample std, needs >= 2 values
st.pstdev(v)                         # population std
min(v) max(v) sum(v) len(v)
```
Edge cases to handle explicitly: empty list, one value (stdev raises), std == 0, None values, division by 0.

## 13. Generators (stream big data)
```python
def read_rows(path):
    with open(path, encoding="utf-8", newline="") as f:
        yield from csv.DictReader(f)          # one row at a time, flat memory
def batched(it, n):
    batch = []
    for x in it:
        batch.append(x)
        if len(batch) == n: yield batch; batch = []
    if batch: yield batch
total = sum(int(r["qty"]) for r in read_rows(p))   # generator expression: no list built
```
`itertools.islice(gen, 10)` takes the first 10 · `itertools.batched(it, n)` (3.12+) is built in.

## 14. Databases (DB-API: sqlite3 and pyodbc work the same)
```python
import sqlite3                     # local practice
conn = sqlite3.connect("db.sqlite")    # ":memory:" for throwaway

import os, pyodbc                  # SQL Server (VPN on!)
conn = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};SERVER=...;DATABASE=Group_XX_DB;"
    f"UID={os.environ['DB_USER']};PWD={os.environ['DB_PASSWORD']};TrustServerCertificate=yes")

cur = conn.cursor()
cur.execute("SELECT * FROM t WHERE year = ? AND city = ?", (2024, "Pisa"))   # ? placeholders
row = cur.fetchone();  rows = cur.fetchall();  chunk = cur.fetchmany(1000)
cols = [d[0] for d in cur.description]
cur.fast_executemany = True                      # pyodbc only: huge speed-up
cur.executemany("INSERT INTO t (a, b) VALUES (?, ?)", list_of_tuples)
conn.commit()                                    # nothing is saved until commit
conn.rollback()                                  # undo since last commit
conn.close()
```
- **Never** build SQL with f-strings around *values* (SQL injection, quote bugs like `O'Brien`). Use `?`.
- Table/column *names* can't be `?`, so validate them (`name.isidentifier()`).
- Bulk load: batches of 1,000–10,000 rows, `fast_executemany`, commit per batch or at the end. Load dimensions before facts (foreign keys).
- Mac + SQL Server: `brew tap microsoft/mssql-release https://github.com/Microsoft/homebrew-mssql-release && brew install msodbcsql18`, then `pip install pyodbc`.
- Sampling on SQL Server: `SELECT TOP (n) ...`, `TABLESAMPLE (5 PERCENT)` (approximate, page-based), or `WHERE ABS(CHECKSUM(NEWID())) % 100 < 5`. Know the trade-offs.
- Credentials: a `.env` file (in `.gitignore`) plus `os.environ`, or `export DB_USER=...` in the terminal.

## 15. Scripts: `__main__`, argparse, logging
```python
import argparse, logging, sys
log = logging.getLogger(__name__)

def main(argv=None):
    p = argparse.ArgumentParser(description="...")
    p.add_argument("input")
    p.add_argument("--out-dir", default="out")
    p.add_argument("--batch-size", type=int, default=1000)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("-v", "--verbose", action="count", default=0)
    args = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING,
                        format="%(asctime)s %(levelname)s %(message)s")
    log.info("reading %s", args.input)
    return 0

if __name__ == "__main__":   # only when run directly, not when imported
    sys.exit(main())
```
Run: `python script.py data.csv --out-dir out -v` · as a module: `python -m package.script ...`
Timing: `import time; t0 = time.perf_counter(); ...; log.info("took %.1fs", time.perf_counter() - t0)`

## 16. pytest
```python
# tests/test_thing.py
import pytest
from mypkg.thing import parse

def test_parse_basic():
    assert parse("a,b") == ["a", "b"]

def test_parse_rejects_empty():
    with pytest.raises(ValueError):
        parse("")

@pytest.mark.parametrize("raw,expected", [("1", 1), ("?", None)])
def test_many(raw, expected):
    assert parse_value(raw) == expected

def test_writes(tmp_path):          # tmp_path: a fresh temp folder per test
    out = tmp_path / "x.csv"
```
`pytest -k name` · `-x` stop at first fail · `-v` verbose · `--lf` last failed · `-s` show prints · `assert x == pytest.approx(0.1 + 0.2)` for floats.

## 17. Gotchas that cost points
| Trap | Wrong | Right |
|---|---|---|
| mutable default arg | `def f(x, acc=[])` (shared across calls!) | `def f(x, acc=None): acc = [] if acc is None else acc` |
| aliasing | `b = a; b.append(1)` changes `a` | `b = a.copy()` / `list(a)` / `copy.deepcopy(a)` for nested |
| `is` vs `==` | `if x is 5` | `==` for values; `is` only for `None`: `if x is None` |
| float equality | `0.1 + 0.2 == 0.3` → False | `math.isclose(a, b)` / `pytest.approx` |
| CSV values are strings | `"10" > "9"` → False | convert: `int(r["qty"])` |
| modifying a list while looping | `for x in l: l.remove(x)` | build a new list |
| integer division | `/` always gives float | `//` floor division |
| forgot `return` | function returns `None` | check every path returns |
| shadowing builtins | `list = [...]`, `dict = ...`, `sum = 0` | pick other names |
| file not closed / wrong encoding | `open(p).read()` | `with open(p, encoding="utf-8")` |
| relative paths | works only from one folder | `Path(__file__).parent / "data"` or pass paths as args |

## 18. Complexity cheat sheet (you know the theory; here is Python's cost)
| Operation | list | dict / set |
|---|---|---|
| `x in` | O(n) | **O(1)** |
| get by index / key | O(1) | O(1) |
| append / add | O(1) amortized | O(1) |
| insert/delete at front | O(n) (use `collections.deque`) | n/a |
| sort | O(n log n) (`sorted`, stable) | n/a |
Rule: membership checks inside a loop → use a **set** or **dict**, never a list. That's the difference between 1 second and 1 hour on the DSS data.

## 19. NumPy & pandas (allowed except DSS A4–A6)
```python
import numpy as np, pandas as pd
a = np.array([3, -1, 4]); a.shape  a.dtype  a * 2  a[a > 0]   # vectorised, masks
np.arange(6).reshape(2, 3)          # (-1, cols): work out the rows
m.mean(axis=0)                      # axis=0: one value per COLUMN
np.where(a > 0, a, 0)               # if/else per element
np.select([a >= 4, a >= 0], ["hi", "mid"], default="neg")   # if/elif/else, first match wins

df = pd.read_csv(p)  # header=None, names=[...], sep=";", na_values=["?"]
df.shape  df.head()  df.info()  df.describe()  df.isnull().sum()     # inspect first
df["c"]  df[["a", "b"]]  df.loc[rows, cols]  df.iloc[0:2, 0:3]       # labels vs positions
df[(df.a > 1) & (df.b == "x")]      # & | ~ and parentheses, never and/or
df[df.c.isin([...])]  df[df.n.between(lo, hi)]  df.query("n > @lim and c == 'x'")
df.replace(["?", -999], np.nan)  df.dropna(subset=[...])  df.fillna(0)
df.astype({"id": int})  pd.to_numeric(s, errors="coerce")  df.rename(columns={...})
pd.to_datetime(df.d)  df.d.dt.year  .dt.month  .dt.day_name()
df.t.str.strip().str.lower()  .str.contains("x")  .str.count(r"#\w+")  .str.extract(r"@(\w+)")
df.duplicated().sum()  df.drop_duplicates(subset=[...], keep="last")  df.drop(columns=[...])
df.sort_values(["a", "b"], ascending=[True, False])
df.c.value_counts()  .map(dict)  .apply(func)  pd.cut(s, bins, labels)  pd.qcut(s, 4)
pd.get_dummies(df, columns=["c"], dtype=int)
df.groupby("c").agg(total=("n", "sum"), cnt=("id", "count")).reset_index()
df.groupby("c")["n"].transform("sum")          # group value on every row
pd.merge(a, b, on="k", how="left", validate="many_to_one")   # check len() before/after
pd.concat([a, b], ignore_index=True)
df.pivot_table(index="r", columns="c", values="n", aggfunc="sum", fill_value=0)   # long → wide
df.melt(id_vars="r", var_name="c", value_name="n")                                # wide → long
df.to_numpy()  df.to_dict("records")  df.to_csv(p, index=False)
```
Methods return a **new** DataFrame: `df = df.dropna()`. `NaN == NaN` is False: use `isnull()`. `np.std` divides by n, pandas `.std()` by n−1.
